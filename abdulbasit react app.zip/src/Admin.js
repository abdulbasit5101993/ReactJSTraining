function Admin(){
    return (
        <div>
            <h1>
                My Admin Page
            </h1>
        </div>
    )
}

export default Admin
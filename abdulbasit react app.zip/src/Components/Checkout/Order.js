import { connect } from 'react-redux';
function Order(props){
    return(
        <div>
            <h5 className="text-center"> Order </h5>
            <div className="text-success">
                Order Have Been Placed Successfully
            </div>
        </div>
    )
}

export default connect(function(state,props){
    return {
        step : state.checkoutstep,
    }
})(Order) 
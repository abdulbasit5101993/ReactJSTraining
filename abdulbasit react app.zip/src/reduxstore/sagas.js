import axios from "axios"
// import { push } from 'react-router-dom';
import {all, call, put, takeEvery, select} from "redux-saga/effects"

function login(action){
    console.log('action login',action.payload)
    return axios({
        method:"post",
        url:"https://apifromashu.herokuapp.com/api/login",
        data:action.payload,
    })      
}

function* LoginGenerator(action, props){
    console.log('action in login saga',action)
    var state = yield select(function(state){
        return state
    })
    var result = yield(call(login,action,props))
    if(result.data.token){
        yield put({type:"LOGIN_SUCCESS",payload:result.data})  
        localStorage.setItem('token', result.data.token);
        console.log('this is the state',state);
    }else{
        yield put({type:"LOGIN_FAILURE"})   
    }
}

export function* LoginSaga(){
    yield takeEvery('LOGIN',LoginGenerator) 
}

export function* GetCartSaga(){
    yield takeEvery('CARTDETAILS',LoginGenerator) 
}

export function* RootSaga(){
    // yield takeEvery('LOGIN',LoginGenerator) 
    yield all([LoginSaga(),GetCartSaga()]) 
}
var demo = function(state ={user:null}, action){
    switch(action.type){
        case "LOGIN":{
            console.log("here we go to login")
            state = {...state}
            state["user"] =action.payload
            return state
        }

        case "LOGIN_SUCCESS":{
            console.log("here we go to login success")
            state = {...state}
            state["isloggedin"]=true
            state["isloader"]=true
            state["user"] =action.payload
            return state
        }
        
        case "LOGIN_FAILURE":{
            console.log("here we go to login failure")
            state = {...state}
            state["isloggedin"]=false
            return state
        }

        case "INTIALIZE_USER":{
            console.log("here we go to login")
            state = {...state}
            state["isloggedin"]=true
            state["user"] =action.payload
            return state
        }

        case "LOGOUT":{
            // console.log("here we go to login")
            state = {...state}
            localStorage.clear()
            delete state["isloggedin"]
            delete state["user"]
            delete state["cardata"]
            delete state["cartdetails"]
            delete state["iscartdata"]
            delete state["checkoutstep"]
            return state
        }

        case "ADDTOCART": {
            state = {...state}
            state["cartdata"] = action.payload
            return state
        }
        
        case "CARTTOTAL": {
            state = {...state}
            state["carttotal"] = action.payload
            return state
        }

        case "CARTDETAILS": {
            state = {...state}
            state["cartdetails"] = action.payload
            state["iscartdata"]=true
            return state
        }

        case "CHECKOUTSTEP": {
            state = {...state}
            state["checkoutstep"]=action.payload
            return state
        }
        
        case "SUMMARYFORM": {
            state = {...state}
            state["summaryform"]=action.payload
            return state
        }
        case "ADDRESSFORM": {
            state = {...state}
            state["addressform"]=action.payload
            return state
        }
        case "PAYMENTFORM": {
            state = {...state}
            state["paymentform"]=action.payload
            return state
        }
        case "ORDERFORM": {
            state = {...state}
            state["orderform"]=action.payload
            return state
        }

        default : return state
    }
}

export default demo